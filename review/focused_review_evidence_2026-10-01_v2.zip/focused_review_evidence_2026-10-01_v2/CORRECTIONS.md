# Preserved numerical correction

The separately coded direct-pair audit checked every one of the 36,864 retained observations and all 144 fits. It found 37 factor-eight fraction-matched 50:50 positive-lobe discrepancies at an exact correlation zero affected by FFT roundoff. Four secondary fits change; maximum change in their exponent difference is about 0.001841. The primary factor-four results and all tolerance classifications are unchanged. Frozen outputs were not replaced.

The included verification JSON retains status `discrepancies_found`, original and direct-recomputed values, exact conditional bootstrap intervals, leave-one-run-out ranges, and every changed secondary fit. These are internal AI-assisted checks, not independent human review.
