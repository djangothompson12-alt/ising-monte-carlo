# Context supporting the October brief

These contextual results are separate from the 16 fresh primary trajectories.
Do not pool their sample sizes or interpret their measurements as equivalent.

## Longer simulations

The [complete declared fit table](research/runs/main_065_multisize_v1/analysis_declared_v1/fit_windows.csv)
includes all sizes, compositions, windows and unresolved fits from the separate
128-trajectory million-sweep study. The cited rows have L=128,
method=primary_unfiltered and nominal window 20000-1000000; actual retained
times are 21336-1000000. These use the periodic engine length, not the
finite-image statistic in the primary experiment. This compact package does
not contain the 128 raw trajectories or reproduce their simulation analysis.
The separate 40-run 0.6 Tc campaign is not included or represented as a
completed literature-method replication.

## Materials-image audit

The [primary FeM summary](output/fem_mask_audit_2026-09-22_v2/field_summary.csv)
and [field measurements](output/fem_mask_audit_2026-09-22_v2/audit/measurements.csv)
cover all 81 fields from one mounted specimen. The
[post-hoc opposite-tie summary](output/fem_mask_audit_2026-09-22_tie_foreground_sensitivity_v1/field_summary.csv)
and [field measurements](output/fem_mask_audit_2026-09-22_tie_foreground_sensitivity_v1/audit/measurements.csv)
change only the treatment of exactly balanced blocks. Both audit manifests
retain the original measurement hashes. The PDF builder independently
recomputes the cited medians from those field rows. This is not a new
pixel-level recalculation or an independent-specimen study.

Source: [Gomes et al., FeM v1](https://doi.org/10.5281/zenodo.5014700).
Microscopy pixels are excluded; their redistribution terms have not been
established. Producer masks are treated as references, not physical truth.
Small length changes are not a laboratory pass without an owner-defined
tolerance. Digital downsampling is not an independently acquired microscope
image. No external user has approved or adopted this tool.

## Exploratory chord appendix

The [summary](research/results/chord_observation_sensitivity_2026-09-26_v2/summary.json)
and [all contrasts](research/results/chord_observation_sensitivity_2026-09-26_v2/contrasts.csv)
reuse the same known 16 trajectories. Processing shifts were smaller for
complete foreground chords than half-height lengths. Edge-censored chords
are excluded, so these are not the published periodic all-domain measurement.
This is exploratory support, not a second untouched confirmation cohort.

## Rebuilding the PDF

The included `research/build_fraction_matching_brief.py` reads the packaged
primary data and context tables. With numpy, Pillow, reportlab and pypdf
installed, run it from the unpacked package:

```bash
python -B -m research.build_fraction_matching_brief --root . --output ../rebuilt_review_brief.pdf
```

Choose an unused output name. The original PDF and its provenance remain
unchanged. Rebuilding reproduces the selected numbers and illustrations, not
independent scientific validation or student approval of its AI-assisted prose.
