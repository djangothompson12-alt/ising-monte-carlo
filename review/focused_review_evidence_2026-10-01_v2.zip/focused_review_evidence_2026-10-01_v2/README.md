# Fraction matching: focused evidence copy

**Local working copy. Not approved by the student, published,
submitted, independently reviewed or externally adopted. Substantial AI assistance.**

[Two-page reviewer brief](review_brief.pdf).

[Long-run, materials-mask and exploratory chord context](CONTEXT.md).

## One question

After reducing image resolution, is preserving the species fraction sufficient
to preserve the measured finite-window coarsening exponent in 2D Kawasaki simulations?
The reference is the native-image exponent, not the theoretical asymptotic 1/3.
This experiment does not identify the entire cause of the native exponent's shortfall.

## Result and scope

Sixteen fresh simulations: eight per composition; 128×128 sites; Jx=Jy=1;
T=0.65 Tc after 200 preparation sweeps at 3 Tc. All simulations are included.
The main comparison uses 4×4 arithmetic block means followed by nearest-count
rank segmentation. Five fixed tie priorities are sensitivity choices, not replicates.
Matching is exact at 50:50 and nearest-integer at 15:85. The same 24 retained
checkpoints span 1,119–20,000 sweeps; the nominal frozen window was 1,000–20,000.
Lengths are finite-image directional connected-covariance half-height crossings,
not the engine's periodic length. Intervals use 1,000 paired whole-run bootstrap draws.

| Nominal +1 species fraction | Native exponent | Fraction-matched exponent | Difference [95% interval] |
|---|---:|---:|---|
| 0.50 | 0.23141 | 0.18094 | -0.05047 [-0.05293, -0.04782] |
| 0.15 | 0.24214 | 0.16563 | -0.07651 [-0.08006, -0.07255] |

Matching fraction did not preserve the exponent in this comparison. It helps at
finer resolution, so this is not a claim that fraction matching always fails.
No new growth law, alloy-specific prediction, certified originality or validated
safe-resolution rule is claimed. Phase area fraction in a real alloy image is
not generally its conserved chemical composition.

## Read or check

- [All 144 frozen comparison fits and report](research/results/growth_reliability_fresh_2026-09-19_v1/report.html).
- [All 36,864 retained observations](research/results/growth_reliability_fresh_2026-09-19_v1/observations.csv), including ties.
- [Frozen protocol](research/GROWTH_RELIABILITY_PROTOCOL_2026-09-19.md).
- [Pre-generation source and seed freeze](research/results/growth_reliability_freeze_2026-09-19_v1.json).
- [Raw campaign plan](research/plans/growth_reliability_holdout_v1.json).
- [Correction audit and all recalculated fit checks](research/results/fresh_arithmetic_audit_2026-09-20_v1/verification.json).
- [Scope of the correction](CORRECTIONS.md).
- [Source classification and file hashes](MANIFEST.json).
- [Metadata-redaction record](PROVENANCE_REDACTION.json).
- [Recorded environments](ENVIRONMENT.json).
- [Saved-data reproduction check](REPRODUCTION_CHECK.json).


The raw NPZ directory contains exactly 16 independently seeded trajectories.
Each archive stores `t` (post-quench sweeps), `snapshots` (±1 sites), `config`
(actual seed/parameters), conserved `magnetization`, `realized_concentration`,
and periodic engine observables. Checkpoints within a run are not independent.

## Reproduce without rerunning Monte Carlo

Unzip into an empty folder and open a terminal in this folder. Use Python 3.11
in a virtual environment; install the recorded numerical dependencies:

```bash
python -m venv .review-venv
.review-venv/bin/python -m pip install -r requirements-numerical.txt
.review-venv/bin/python -B -m research.verify_review_copy .
.review-venv/bin/python -B -m research.verify_study research/runs/growth_reliability_holdout_v1 --source-root .
.review-venv/bin/python -B -m research.audit_growth_reliability research/runs/growth_reliability_holdout_v1 --cohort fresh --freeze research/results/growth_reliability_freeze_2026-09-19_v1.json --output ../fresh_fraction_replay
```

On Windows use the virtual environment's `Scripts/python.exe`. The analysis
output must be new. Compare its `fits.csv` and `observations.csv` with the frozen
files here. Exact-byte agreement is an environment-specific reproducibility check;
different numerical libraries can change roundoff, especially first-zero decisions.
For an independent arithmetic implementation, optionally run:

```bash
.review-venv/bin/python -B -m research.audit_fresh_measurements research/runs/growth_reliability_holdout_v1 ../fresh_fraction_replay --output ../fresh_direct_pair_audit
```

That audit is expected to report **discrepancies_found**, not a clean pass:
the recorded factor-eight secondary boundary issue is preserved and disclosed.
The primary factor-four result is unchanged. The two predeclared warning
screens accepted zero of 18 comparisons and have no demonstrated usable coverage.
Use the **new reanalysis directory** in that command: its derived campaign-manifest
hash matches this redacted copy. Running the audit directly against the frozen
original output will intentionally reject the changed manifest hash. If included,
`primary_audit/audit_primary.py` is an unchanged record of the additional local
check, not a portable command: it retains its original-path and manifest checks.

## Provenance and privacy

The nine recorded frozen sources, all raw archives and the frozen analysis
tables are byte-identical copies checked against their old hashes. Current
support dependencies and later checking/packaging scripts are identified separately;
they were not all covered by the original nine-file freeze. This copy preserves
the original environment record but does not claim that provenance freeze was complete.

The original campaign manifest included private-note filenames in `git_status`.
That field is omitted here. Its numerical identity is unchanged, but its hash is
different. The untouched frozen analysis manifest still records the original hash;
the redaction record explains this intentional mismatch. New reanalysis should
recover the numeric tables, **not** the original analysis-manifest hash.
Original private notes, third-party microscopy images, raw data from other
campaigns and old paper drafts are not included. If CONTEXT.md is present,
it lists separate aggregate context tables and their limited verification scope.
No simulation source or raw-data file in the working project was altered.

Code, design, analysis, checking and prose have had substantial AI assistance.
This is not evidence that Django independently completed or already understands
every step. Student explanation/approval and specialist criticism remain necessary.
